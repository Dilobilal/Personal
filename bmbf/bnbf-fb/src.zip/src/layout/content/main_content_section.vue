<template>
    <div>
        <div class="container-xxl bg-white p-0">
            <!-- Spinner Start -->
            <div id="spinner" :class="spinner"
                class=" bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
                <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                    <span class="sr-only">Loading...</span>
                </div>
            </div>
            <!-- Spinner End -->
            <div class="container-fluid">
                <main class="tm-main-article">
                    <div class="row">
                        <div class="col">
                            <hr class="tm-hr-primary">
                            <div class="row">
                                <div class="col">
                                    <div>
                                        <h2 class="pt-2 tm-color-primary tm-post-title">Title</h2>
                                        <div v-html="inhalte"></div>
                                        <!-- Comments -->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <aside class="col-lg-4 tm-aside-col">
                            <div class="tm-post-sidebar">
                                <hr class="mb-3 tm-hr-primary">
                                <h2 class="mb-4 tm-post-title tm-color-primary">Categories</h2>
                                <ul class="tm-mb-75 pl-5 tm-category-list">
                                    <li><a href="#" class="tm-color-primary">Visual Designs</a></li>
                                    <li><a href="#" class="tm-color-primary">Travel Events</a></li>
                                    <li><a href="#" class="tm-color-primary">Web Development</a></li>
                                    <li><a href="#" class="tm-color-primary">Video and Audio</a></li>
                                    <li><a href="#" class="tm-color-primary">Etiam auctor ac arcu</a></li>
                                    <li><a href="#" class="tm-color-primary">Sed im justo diam</a></li>
                                </ul>
                                <hr class="mb-3 tm-hr-primary">
                                <h2 class="tm-mb-40 tm-post-title tm-color-primary">Related Posts</h2>
<!--
                                <a href="#" class="d-block tm-mb-40" v-for="x in lastPosts" :key="x.id">
                                    <figure>
                                        <img v-bind:src="x.Image" alt="Image" class="mb-3 img-fluid">
                                        <figcaption class="tm-color-primary">{{ x.Title }}</figcaption>
                                    </figure>
                                </a>
-->
                            </div>

                        </aside>
                    </div>


                </main>
            </div>
        </div>
    </div>
</template>

<script>
import { createDirectus, rest, readItems, createItems } from '@directus/sdk';
//import { injectDataIntoContent } from "directus-extension-flexible-editor/content/";

export default {

    name: "content_section",
    data() {
        return {
            inhalte: "",
            spinner: "d-none",
        }
    },
    methods: {
        async personalisieren() {
            this.$store.commit('initUserinfo');
            this.spinner = "";
            const client = createDirectus('http://localhost:8055').with(rest());
            const UserData = {
                vorwissen: this.$store.state.userinfo.vorwissen,
                sprache: this.$store.state.userinfo.sprache,
                lerntypen: this.$store.state.userinfo.lerntypen,
                altersgruppe: this.$store.state.userinfo.altersgruppe
            };
            var response = await client.request(createItems('benutzer_einstellungen', UserData));
            console.log(response);
            if (this.$store.state.userinfo.lerntypen === this.$store.state.Lerntypen.Lesende) {
                if (this.$store.state.userinfo.sprache === this.$store.state.Sprache.DE) {
                    var cont = await client.request(readItems('deutsche_inhalt'));
                    if (this.$store.state.userinfo.altersgruppe === this.$store.state.Altersgruppe.Kinder && this.$store.state.userinfo.vorwissen === this.$store.state.VorWissen.Anfanger) {
                        this.parseDirectusBlocks(cont.Kinder_Anfanger);
                    }
                    else if (this.$store.state.userinfo.altersgruppe === this.$store.state.Altersgruppe.Jugendliche && this.$store.state.userinfo.vorwissen === this.$store.state.VorWissen.Anfanger) {
                        this.parseDirectusBlocks(cont.Jugendliche_Anfanger);

                    }
                    else if (this.$store.state.userinfo.altersgruppe === this.$store.state.Altersgruppe.Jugendliche && this.$store.state.userinfo.vorwissen === this.$store.state.VorWissen.Fortgeschrittene) {
                        this.parseDirectusBlocks(cont.Jugendliche_Fortgeschrittene);

                    }
                    else if (this.$store.state.userinfo.altersgruppe === this.$store.state.Altersgruppe.Junge_Erwachsene && this.$store.state.userinfo.vorwissen === this.$store.state.VorWissen.Anfanger) {
                        this.parseDirectusBlocks(cont[0].Junge_Erwachsene_Anfanger);

                    }
                    else if (this.$store.state.userinfo.altersgruppe === this.$store.state.Altersgruppe.Junge_Erwachsene && this.$store.state.userinfo.vorwissen === this.$store.state.VorWissen.Fortgeschrittene) {
                        this.parseDirectusBlocks(cont.Junge_Erwachsene_Fortgeschrittene);

                    }
                    else if (this.$store.state.userinfo.altersgruppe === this.$store.state.Altersgruppe.Junge_Erwachsene && this.$store.state.userinfo.vorwissen === this.$store.state.VorWissen.Experten) {
                        this.parseDirectusBlocks(cont.Junge_Erwachsene_Experten);

                    }
                    else if ((this.$store.state.userinfo.altersgruppe === this.$store.state.Altersgruppe.Erwachsene || this.$store.state.userinfo.altersgruppe === this.$store.state.Altersgruppe.Senioren) && this.$store.state.userinfo.vorwissen === this.$store.state.VorWissen.Anfanger) {
                        console.log(cont.Junge_Erwachsene_Anfanger);
                        this.parseDirectusBlocks(cont.Erwachsene_Seioren_Anfanger);

                    }
                    else if ((this.$store.state.userinfo.altersgruppe === this.$store.state.Altersgruppe.Erwachsene || this.$store.state.userinfo.altersgruppe === this.$store.state.Altersgruppe.Senioren) && this.$store.state.userinfo.vorwissen === this.$store.state.VorWissen.Fortgeschrittene) {
                        this.parseDirectusBlocks(cont.Erwachsene_Seioren_Fortgeschrittene);

                    }
                    else if ((this.$store.state.userinfo.altersgruppe === this.$store.state.Altersgruppe.Erwachsene || this.$store.state.userinfo.altersgruppe === this.$store.state.Altersgruppe.Senioren) && this.$store.state.userinfo.vorwissen === this.$store.state.VorWissen.Experten) {
                        this.parseDirectusBlocks(cont.Erwachsene_Senioren_Experten);

                    } else {
                        this.inhalte = "<h2>NO Content Found</h2>"
                    }
                } else {
                    this.inhalte = "<h2>NO Content Found</h2>"
                }
            } else {
                this.inhalte = "<h2>NO Content Found</h2>"

            }
            this.spinner = "d-none";
        },
        parseDirectusBlocks(blocks) {
            this.inhalte = blocks;

        }
    },
    async mounted() {
        await this.personalisieren();
    }
}
</script>

<style></style>