<template>
  <h2>Hello</h2>
</template>

<script>
export default {

}
</script>

<style>

</style>